<div class="view">

	<b><?php echo MiscHelper::niceDate($data->time_euh) ?>:</b>
	<?php echo $data->action_euh; ?>

</div>