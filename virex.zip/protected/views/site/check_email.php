<?php if ($ok){ ?>
	Your email address has been validated and an administrator has been notified. You will receive a new message when your account is activated. <br />
<?php } else	{ ?>
	Wrong code!
<?php }?>